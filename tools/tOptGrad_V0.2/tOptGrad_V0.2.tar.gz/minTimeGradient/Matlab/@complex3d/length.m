function res = length(a)

res = size(a.data,1);

