function res = abs(a)

res = sqrt(sum(a.data.^2,2));

